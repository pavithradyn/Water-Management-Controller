#include <WiFi.h>
#include <HTTPClient.h>

// ---------- WiFi (Wokwi simulated network) ----------
const char* WIFI_SSID     = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";

// ---------- Firebase REST config ----------
// Use your Realtime Database URL, e.g. https://water-management-iot-default-rtdb.firebaseio.com
const char* DATABASE_URL = "https://watermanagementcontroller-default-rtdb.asia-southeast1.firebasedatabase.app/";
// ---------- GPIO pin map ----------
#define PIN_TANK_LEVEL   34
#define PIN_SUMP_LEVEL   35
#define PIN_FLOW_RATE    32
#define PIN_PUMP_FB      25

#define PIN_PUMP_LED     18
#define PIN_INLET_LED    19
#define PIN_OUTLET_LED   21
#define PIN_BUZZER_LED   22
#define PIN_FAULT_LED    23
#define PIN_BUZZER       27

// ---------- Thresholds ----------
#define TANK_LOW_PCT      20
#define TANK_HIGH_PCT     90
#define SUMP_LOW_PCT      15
#define DRYRUN_SUMP_PCT   10

// ---------- State variables (mirrors Firebase keys) ----------
int  tankLevel = 0, sumpLevel = 0, flowRate = 0;
bool pumpFeedback = false;
bool dryRunStatus = false, overflowStatus = false;
bool pumpStatus = false, inletValveStatus = false, outletValveStatus = false;
bool alertStatus = false;

// Commands read FROM Firebase
bool pumpCommand = false, inletValveCommand = false, outletValveCommand = false;
bool buzzerCommand = false, resetFaultCommand = false;
int  modeCommand = 0;   // 0 = AUTO, 1 = MANUAL

unsigned long lastUpload = 0;
unsigned long lastCommandPoll = 0;
const unsigned long UPLOAD_INTERVAL = 3000;
const unsigned long POLL_INTERVAL   = 2000;

// ---------------- WiFi connect ----------------
void connectWiFi() {
  Serial.print("Connecting to WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected.");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());
}

// ---------------- Firebase REST helpers ----------------
// PUT a single value to a path, e.g. setFirebase("tankLevel", "55")
bool setFirebaseValue(const String& path, const String& jsonValue) {
  if (WiFi.status() != WL_CONNECTED) return false;
  HTTPClient http;
  String url = String(DATABASE_URL) + "/waterManagement/" + path + ".json";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  int code = http.PUT(jsonValue);
  http.end();
  return (code == 200);
}

// GET a single value, returns raw response body (e.g. "1" or "0" or "null")
String getFirebaseValue(const String& path) {
  if (WiFi.status() != WL_CONNECTED) return "";
  HTTPClient http;
  String url = String(DATABASE_URL) + "/waterManagement/" + path + ".json";
  http.begin(url);
  int code = http.GET();
  String payload = "";
  if (code == 200) payload = http.getString();
  http.end();
  return payload;
}

// ---------------- Sensor reading ----------------
void readSensors() {
  int rawTank = analogRead(PIN_TANK_LEVEL);   // 0-4095
  int rawSump = analogRead(PIN_SUMP_LEVEL);
  int rawFlow = analogRead(PIN_FLOW_RATE);

  tankLevel = map(rawTank, 0, 4095, 0, 100);
  sumpLevel = map(rawSump, 0, 4095, 0, 100);
  flowRate  = map(rawFlow, 0, 4095, 0, 50);   // simulated 0-50 LPM

  pumpFeedback = (digitalRead(PIN_PUMP_FB) == LOW); // pressed = active feedback
}

// ---------------- Fault / automation logic ----------------
void evaluateLogic() {
  // Dry-run protection: pump commanded ON but sump too low
  dryRunStatus = (pumpCommand && sumpLevel < DRYRUN_SUMP_PCT);

  // Overflow protection: tank above high threshold while inlet still open
  overflowStatus = (tankLevel >= TANK_HIGH_PCT && inletValveStatus);

  // Auto mode pump logic (only acts if modeCommand == 0 / AUTO)
  if (modeCommand == 0) {
    if (tankLevel < TANK_LOW_PCT && sumpLevel > DRYRUN_SUMP_PCT && !dryRunStatus) {
      pumpCommand = true;
    }
    if (tankLevel >= TANK_HIGH_PCT) {
      pumpCommand = false;
    }
  }

  // Safety override: dry-run or overflow forces pump OFF regardless of mode
  if (dryRunStatus || overflowStatus) {
    pumpCommand = false;
  }

  alertStatus = (dryRunStatus || overflowStatus);

  // Reset fault command clears alert + forces re-evaluation
  if (resetFaultCommand) {
    dryRunStatus = false;
    overflowStatus = false;
    alertStatus = false;
    resetFaultCommand = false;
    setFirebaseValue("resetFaultCommand", "0");
  }
}

// ---------------- Apply outputs to actuators ----------------
void applyOutputs() {
  pumpStatus        = pumpCommand;
  inletValveStatus   = inletValveCommand;
  outletValveStatus  = outletValveCommand;

  digitalWrite(PIN_PUMP_LED,   pumpStatus ? HIGH : LOW);
  digitalWrite(PIN_INLET_LED,  inletValveStatus ? HIGH : LOW);
  digitalWrite(PIN_OUTLET_LED, outletValveStatus ? HIGH : LOW);
  digitalWrite(PIN_FAULT_LED,  alertStatus ? HIGH : LOW);

  bool buzzerOn = buzzerCommand || alertStatus;
  digitalWrite(PIN_BUZZER_LED, buzzerOn ? HIGH : LOW);
  digitalWrite(PIN_BUZZER, buzzerOn ? HIGH : LOW);
}

// ---------------- Upload sensor + status data to Firebase ----------------
void uploadToFirebase() {
  setFirebaseValue("tankLevel",          String(tankLevel));
  setFirebaseValue("sumpLevel",          String(sumpLevel));
  setFirebaseValue("flowRate",           String(flowRate));
  setFirebaseValue("pumpFeedback",       pumpFeedback ? "1" : "0");
  setFirebaseValue("dryRunStatus",       dryRunStatus ? "1" : "0");
  setFirebaseValue("overflowStatus",     overflowStatus ? "1" : "0");
  setFirebaseValue("pumpStatus",         pumpStatus ? "1" : "0");
  setFirebaseValue("inletValveStatus",   inletValveStatus ? "1" : "0");
  setFirebaseValue("outletValveStatus",  outletValveStatus ? "1" : "0");
  setFirebaseValue("alertStatus",        alertStatus ? "1" : "0");

  Serial.println("---- Uploaded to Firebase ----");
  Serial.printf("Tank:%d%% Sump:%d%% Flow:%dLPM PumpFB:%d\n",
                 tankLevel, sumpLevel, flowRate, pumpFeedback);
  Serial.printf("Pump:%d Inlet:%d Outlet:%d DryRun:%d Overflow:%d Alert:%d\n",
                 pumpStatus, inletValveStatus, outletValveStatus,
                 dryRunStatus, overflowStatus, alertStatus);
}

// ---------------- Poll commands FROM Firebase ----------------
void pollCommands() {
  String v;

  v = getFirebaseValue("pumpCommand");
  if (v.length() && v != "null") pumpCommand = (v.toInt() == 1);

  v = getFirebaseValue("inletValveCommand");
  if (v.length() && v != "null") inletValveCommand = (v.toInt() == 1);

  v = getFirebaseValue("outletValveCommand");
  if (v.length() && v != "null") outletValveCommand = (v.toInt() == 1);

  v = getFirebaseValue("buzzerCommand");
  if (v.length() && v != "null") buzzerCommand = (v.toInt() == 1);

  v = getFirebaseValue("modeCommand");
  if (v.length() && v != "null") modeCommand = v.toInt();

  v = getFirebaseValue("resetFaultCommand");
  if (v.length() && v != "null") resetFaultCommand = (v.toInt() == 1);

  Serial.println("---- Commands polled from Firebase ----");
  Serial.printf("PumpCmd:%d InletCmd:%d OutletCmd:%d BuzzerCmd:%d Mode:%d Reset:%d\n",
                 pumpCommand, inletValveCommand, outletValveCommand,
                 buzzerCommand, modeCommand, resetFaultCommand);
}

// ---------------- Setup ----------------
void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(PIN_PUMP_FB, INPUT_PULLUP);
  pinMode(PIN_PUMP_LED, OUTPUT);
  pinMode(PIN_INLET_LED, OUTPUT);
  pinMode(PIN_OUTLET_LED, OUTPUT);
  pinMode(PIN_BUZZER_LED, OUTPUT);
  pinMode(PIN_FAULT_LED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);

  connectWiFi();

  Serial.println("==== Water Management Controller booted ====");
}

// ---------------- Main loop ----------------
void loop() {
  unsigned long now = millis();

  readSensors();
  evaluateLogic();
  applyOutputs();

  if (now - lastCommandPoll >= POLL_INTERVAL) {
    pollCommands();
    lastCommandPoll = now;
  }

  if (now - lastUpload >= UPLOAD_INTERVAL) {
    uploadToFirebase();
    lastUpload = now;
  }

  delay(200);
}